# Food-App
Food app like zomato using html, CSS &amp; Js 

✅DeployLink: https://inspiring-gnome-8e6791.netlify.app

# landing page
![Food App](https://user-images.githubusercontent.com/81063456/160273033-19fbfcfd-9876-4796-b1db-200a669c3daf.png)

# Cart page
![cart page](https://user-images.githubusercontent.com/81063456/160273043-5e833526-d5f2-4d23-b09f-afe1df3caeea.png)

# Wallet page
![image](https://user-images.githubusercontent.com/81063456/160273064-8b00eec5-c199-4f98-b9c4-c10b758c8082.png)


# Sign up Page
![image](https://user-images.githubusercontent.com/81063456/160273084-cb1f698b-31c3-469a-8f46-28f20ef7d5cb.png)

# Login Page
![image](https://user-images.githubusercontent.com/81063456/160273096-fedb4caf-3d62-4fea-9ec0-50d4747af565.png)

# Favorite food page
![image](https://user-images.githubusercontent.com/81063456/160273117-b82272a0-6821-406c-9fff-09ab390412b5.png)

# Checkout page

![image](https://user-images.githubusercontent.com/81063456/160273130-e43f1005-cbf5-45e7-8767-de67ade3000b.png)

# Thank You
![image](https://user-images.githubusercontent.com/81063456/160273159-fb46aa61-6a40-4b45-85ff-c3ce33f45d83.png)
